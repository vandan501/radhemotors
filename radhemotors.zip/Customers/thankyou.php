<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="5; url=../index.html">
    <title>Visit Again</title>
    <style>
    h1{

        color:white;
    }
    .div{
        padding : 190px
    }
    </style>
</head>
<body bgcolor="black">
<div class="div">
<center>
    <h1>THANK YOU FOR SHOPPING WITH US :) </h1>


    <h1>VISIT AGAIN!!!</h1>
    </center>
    </div>
</body>
</html>
<?php
session_start();
unset($_SESSION["c_id"]);
unset($_SESSION["c_fname"]);

?>